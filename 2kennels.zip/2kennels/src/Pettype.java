public enum Pettype {
    aDog,
    aCat
}
