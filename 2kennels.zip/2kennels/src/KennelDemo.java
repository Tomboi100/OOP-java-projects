import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * This class runs a Kennel
 *
 * @author Chris Loftus Tommy Boyle
 * @version 6th April 2021
 */
public class KennelDemo {
    private String filename; // holds the name of the file
    private Kennel kennel; // holds the kennel
    private Scanner scan; // so we can read from keyboard
    private String fileBuffer;

    /*
     * Notice how we can make this constructor private, since we only call from main which
     * is in this class. We don't want this class to be used by any other class.
     */
    private KennelDemo() {
        kennel = new Kennel();
        scan = new Scanner(System.in);
        System.out.println("Would you like to create(c) a new file or load(l) a file?");
        String choice = scan.nextLine().toUpperCase();
        if (choice.equals("C")){
            System.out.println("Please enter the name of the file you want to create for kennel information without .txt:");
            String input = scan.nextLine();
            fileCreate(input);

        }
        System.out.print("Please enter the filename of kennel information without .txt: ");
        fileBuffer = scan.nextLine();
        filename = fileBuffer + ".txt";
    }
    private void fileCreate(String name) {
        try {
            kennel.create(name);
        } catch (IOException e) {
            System.err.println("Problem when trying to write to file: " + filename);
        }
    }

    /*
     * initialise() method runs from the main and reads from a file
     */
    private void initialise() {
        System.out.println("Using file " + filename);

        try {
            kennel.load(filename);
        } catch (FileNotFoundException e) {
            System.err.println("The file: " + filename + " does not exist. Assuming first use and an empty file." +
                    " If this is not the first use then have you accidentally deleted the file?");
        } catch (IOException e) {
            System.err.println("An unexpected error occurred when trying to open the file " + filename);
            System.err.println(e.getMessage());
        }
    }

    /*
     * runMenu() method runs from the main and allows entry of data etc
     */
    private void runMenu() {
        String response;
        do {
            printMenu();
            System.out.println("What would you like to do:");
            scan = new Scanner(System.in);
            response = scan.nextLine().toUpperCase();
            switch (response) {
                case "1":
                    admitPet();
                    break;
                case "2":
                    changeKennelName();
                    break;
                case "3":
                    printAll();
                    break;
                case "4":
                    searchForPet();
                    break;
                case "5":
                    removePet();
                    break;
                case "6":
                    setKennelCapacity();
                    break;
                case "Q":
                    break;
                default:
                    System.out.println("Try again");
            }
        } while (!(response.equals("Q")));
    }

    private void printMenu() {
        System.out.println("1 -  add a new Pet ");
        System.out.println("2 -  set up Kennel name");
        System.out.println("3 -  display all inmates and info");
        System.out.println("4 -  search for a pet");
        System.out.println("5 -  remove a Pet");
        System.out.println("6 -  set kennel capacity");
        System.out.println("q - Quit");
    }

    private void setKennelCapacity() {
        System.out.print("Enter max number of pets: ");
        int max = scan.nextInt();
        scan.nextLine();
        kennel.setCapacity(max);
    }

    /*
     * printAll() method runs from the main and prints status
     */
    private void printAll() {
        System.out.println(kennel.obtainAllInmates());
        //System.out.println(kennel.toString());
    }

    private void removePet() {
        System.out.println("what Pet would you like to remove cat or dog (C/D)");
        String petD = scan.nextLine().toUpperCase();
        System.out.println("enter pet name");
        String pettoberemoved = scan.nextLine();
        if (petD.equals("C")){
            kennel.removeCat(pettoberemoved);
        } else if (petD.equals("D")){
            kennel.removeDog(pettoberemoved);
        }else{
            System.out.println("invalid dog/cat input");
        }
    }

    private void searchForPet() {
        System.out.println("which pet do you want to search for");
        String name = scan.nextLine();
        Pet pet = kennel.search(name);
        if (pet != null) {
            System.out.println(pet.toString());
        } else {
            System.out.println("Could not find pet: " + name);
        }
    }

    private void changeKennelName() {
        System.out.println("enter new kennel name");
        String name = scan.nextLine();
        kennel.setName(name);
    }

    private void admitPet() {
        boolean lb = false;
        boolean sr = false;
        System.out.println("Is the the Pet a dog or cat (D/C)");
        String dec = scan.nextLine().toUpperCase();
        if (dec.equals("D")){

            System.out.println("enter on separate lines: name, likeBones?, favourite food, number of times fed, owner-name, owner-phone, ");
            String name = scan.nextLine();
            System.out.println("Does he/she like bones? (Y/N)");
            String likeBones;
            likeBones = scan.nextLine().toUpperCase();
            if (likeBones.equals("Y")) {
                lb = true;
            }
            System.out.println("What is his/her favourite food?");
            String fav;
            fav = scan.nextLine();
            System.out.println("How many times is he/she fed a day? (as a number)");
            int numTimes;
            numTimes = scan.nextInt(); // This can be improved (InputMismatchException?)
            scan.nextLine(); // Clear the end of line characters because I didn't use a delimiter
            Dog newDog = new Dog(name, lb, fav, numTimes);
            ArrayList<Owner> owners = getOwners();
            for(Owner o: owners){
                newDog.setOriginalOwners(o);
            }

            kennel.addDog(newDog);

        } else if (dec.equals("C")){
            System.out.println("enter on separate lines: name, share a run?, favourite food?, number of times fed, owner-name, owner-phone, ");
            System.out.println("enter name");
            String name = scan.nextLine();
            System.out.println("Can he/she share a run (Y/N)");
            String shareRun;
            shareRun = scan.nextLine().toUpperCase();
            if (shareRun.equals("Y")) {
                sr = true;
            }
            System.out.println("What is his/her favourite food?");
            String fav;
            fav = scan.nextLine();
            System.out.println("How many times is he/she fed a day? (as a number)");
            int numTimes;
            numTimes = scan.nextInt(); // This can be improved (InputMismatchException?)
            scan.nextLine(); // Clear the end of line characters because I didn't use a delimiter
            Cat newCat = new Cat(name, sr, fav, numTimes);
            ArrayList<Owner> owners = getOwners();
            for(Owner o: owners){
                newCat.setOriginalOwners(o);
            }

            kennel.addCat(newCat);

        }else {
            System.out.println("invalid input");
        }
    }

    private ArrayList<Owner> getOwners() {
        ArrayList<Owner> owners = new ArrayList<Owner>();
        String answer;
        do {
            System.out.println("Enter on separate lines: owner-name owner-phone");
            System.out.println("enter name");
            String ownName = scan.nextLine();
            System.out.println("enter phone number");
            String ownPhone = scan.nextLine();
            Owner own = new Owner(ownName, ownPhone);
            owners.add(own);
            System.out.println("Another owner (Y/N)?");
            answer = scan.nextLine().toUpperCase();
        } while (!answer.equals("N"));
        return owners;
    }

    /*
     * save() method runs from the main and writes back to file
     */
    private void save() {
        try {
            kennel.save(filename);
        } catch (IOException e) {
            System.err.println("Problem when trying to write to file: " + filename);
        }
    }

    private void backup() {
        try {
            kennel.save(fileBuffer + "-bck.txt");
        } catch (IOException e) {
            System.err.println("Problem when trying to write to file: " + filename);
        }
    }

    // /////////////////////////////////////////////////
    public static void main(String args[]) {
        System.out.println("**********HELLO***********");
        KennelDemo demo = new KennelDemo();
        demo.initialise();
        demo.runMenu();
        demo.printAll();
        // MAKE A BACKUP COPY OF data.txt JUST IN CASE YOU CORRUPT IT
        demo.save();
        demo.backup();
        System.out.println("***********GOODBYE**********");
    }
}
