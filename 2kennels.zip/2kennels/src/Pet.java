import java.util.ArrayList;

public class Pet implements Comparable<Pet>{
    private ArrayList<Owner> originalOwners;
    private String petName;
    private String favFood;
    private int foodPerDay;
    private Pettype petType;

    /**
     * No argument constructor
     */
    public Pet(){this("unknown","unknown",1);}

    public Pet(String name, String food, int foodPer) {
        originalOwners = new ArrayList<Owner>();
        this.petName = name;
        this.favFood = food;
        this.foodPerDay = foodPer;
    }

    /**
     * returns the arraylist of owners for the pet
     * @return
     */
    public Owner[] getOriginalOwners() {
        Owner[] result = new Owner[originalOwners.size()];
        result = originalOwners.toArray(result);
        return result;
    }

    /**
     * adds an Owner to the arraylist of owners
     * @param oriOwners
     */
    public void setOriginalOwners(Owner oriOwners) {
        originalOwners.add(oriOwners);
    }

    /**
     * returns the pets name
     * @return
     */
    public String getPetName() {
        return petName;
    }

    /**
     * sets the pets name
     * @param petName
     */
    public void setPetName(String petName) {
        this.petName = petName;
    }

    /**
     * gets the favourite food of the pet
     * @return
     */
    public String getFavFood() {
        return favFood;
    }

    /**
     * sets the pets favourite food
     * @param favFood
     */
    public void setFavFood(String favFood) {
        this.favFood = favFood;
    }

    /**
     * gets the meals per day for the pet
     * @return
     */
    public int getFoodPerDay() {
        return foodPerDay;
    }

    /**
     * sets the meal per day for the pet
     * @param foodPerDay
     */
    public void setFoodPerDay(int foodPerDay) {
        this.foodPerDay = foodPerDay;
    }

    /**
     * gets the type of pet that the pet is for example Dog or Cat
     * @return
     */
    public Pettype getPetType() {
        return petType;
    }

    /**
     * Sets the type of pet for example Dog or Cat
     * @param petType
     */
    public void setPetType(Pettype petType) {
        this.petType = petType;
    }

    /**
     * compareto method for comparing and sorting the pets alphabetically by name
     * @param o
     * @return
     */
    @Override
    public int compareTo(Pet o) {
        return getPetName().compareTo(o.getPetName());
    }
}
